Markdown files in this folder can be used for tasks like:

* Taking screenshots after a syntax highlighting update in the plugin,
* Checking if the plugin works legitimately in general.
