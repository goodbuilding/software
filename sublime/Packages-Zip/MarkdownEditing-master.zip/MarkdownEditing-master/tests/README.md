These are some example files to test if the syntax highlighting works correctly. They include some edge cases, too.
