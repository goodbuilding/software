[1]: https://github.com/revolunet/sublimetext-markdown-preview
