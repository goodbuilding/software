# python desktop

This module has been extracted from Python core and benefits of some improvements.

The goal of this module is simply to open documents with the default system viewer on various OS.

The module is used in some of @revolunet SublimeText plugin, mainly to open web pages.


## Licence

The original module license is "GNU Lesser General Public License"
